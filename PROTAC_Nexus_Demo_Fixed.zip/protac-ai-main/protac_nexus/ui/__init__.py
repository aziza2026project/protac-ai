"""Reusable user-interface helpers."""
